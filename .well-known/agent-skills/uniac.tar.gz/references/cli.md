# CLI

`npm install -g @uniac/cli` installs the `uniac` command with Node 18+.
Alternatively, `npx -y @uniac/cli …` runs any `uniac …` invocation without
a global installation.

Commands that take a local directory default to the current directory.

For commands accepting positional arguments, parsing stops at the first
positional argument; trailing flags are ignored. `uniac -h` lists commands
and `uniac <command> -h` lists flags.

## Commands

| Command | Effect |
|---|---|
| `init` | Creates a [starter manifest](#planning-and-deployment). |
| `plan [deployment]` | Previews a [deployment declaration](#planning-and-deployment). |
| `project create <name>` | Creates a [remote project](#project-selection). |
| `link [name-or-slug]` | Creates or replaces a [directory's project binding](#project-selection). |
| `deploy [deployment]` | Requests [deployment](#planning-and-deployment) of the selected declaration. |
| `status [service]` | Reads current state for a linked project, including services absent from the local manifest, or one named service. |
| `auth <login\|status\|token\|logout>` | Manages account credentials; see [Authentication](#authentication). |
| `version` | Prints the installed version. |

The CLI has no removal command.

## Authentication

`auth login` stores the token returned by browser sign-in for the selected
platform, replacing any previous session for that platform. Sign-in requires
the user's browser interaction, with account creation available there. The CLI
prints the sign-in URL and reports whether the browser opened.

`project create`, `link`, `deploy`, `status`, and `auth token` use
`UNIAC_ACCESS_TOKEN` when nonempty, otherwise the selected platform's session in
`~/.uniac/auth.json`. A stored token becomes unusable 60 seconds before its
recorded expiry. The CLI does not refresh tokens automatically.

`auth status` reads stored sessions and expiry locally. Its `Logged in.`
message means stored sessions exist, even when expired. It does not validate
credentials with the platform or inspect `UNIAC_ACCESS_TOKEN`.
`auth token` prints the selected credential. `auth logout` removes all
locally stored platform sessions.

| Variable | Meaning |
|---|---|
| `UNIAC_PLATFORM_URL` | Platform API origin for login, `auth token`, project creation, linking, and target overrides. Default: `https://api.uniac.ai`. |
| `UNIAC_AUTH_HOST` | Browser sign-in host. Defaults to `uniac.ai` for the default platform; required for another platform unless login's `--host` is supplied. |

## Project selection

Deployment targets an existing remote project. `project create <name>` creates
one without writing local files. `link [name-or-slug]` associates a local
directory containing `uniac.yaml` with an existing project; omitting the
argument opens a project picker.

`link` writes `.uniac/deploy.json`, containing
`{project_slug, project_name, gateway_url, platform_url}`: `project_name` is
the name given at `project create`, unique within the account; `project_slug`
is the identifier the platform assigned the project, and the label of its
gateway host; `gateway_url` is the project's gateway, the endpoint the CLI
pushes images to and registers services with; `platform_url` is the platform
API origin the project belongs to (`https://api.uniac.ai` by default), which
a linked directory follows without any environment setting. The deploy
project picker can also write this binding.

`UNIAC_PROJECT_URL` supplies a gateway URL or project slug, overriding the
binding without supplying a project name. Without this override, `deploy`
and `status` use the binding's platform; a conflicting `UNIAC_PLATFORM_URL`
fails before a network call.

Without a binding or target override, `deploy` opens the project picker.
An unattended invocation fails if selection requires interaction.

## Planning and deployment

`init` writes a starter `uniac.yaml` in a local directory without one. It
declares a prebuilt-image service and its deployment. It runs offline and
takes defaults when unattended; `npm create @uniac@latest` invokes it.

`plan` and `deploy` read `uniac.yaml` from the selected local directory.
They select the explicitly named deployment, otherwise `default`, otherwise
the manifest's sole deployment; failure to select a deployment is an error.

`plan` requires no credentials, network, or Docker. `deploy` additionally
requires an [existing remote project](#project-selection),
[credentials for its platform](#authentication), and a local Docker daemon
for either `image:` or `build:`.

A deploy target must contain exactly one entry in `services`. Deployment
performs local planning before any remote action.

Prebuilt images are pulled with local Docker credentials. Images target `linux/amd64`.
Builds use the current working tree; the context directory's `.dockerignore`
filters build input, while `.gitignore` does not. Builds run on each
deployment, using Docker's layer cache, with no injected build arguments.
The resulting image is pushed to the project registry.

`UNIAC_STORE_DIR` selects the local release-record directory, which defaults
to `~/.uniac/store`.

With a project name, deployment task ID, and successful initial task read,
the CLI waits for completion or the observation deadline. Without those
conditions, it can return success after registration without observing
completion. Interrupting the CLI does not cancel work already accepted by
the platform.

## Output

`link` writes its listing, prompt, and confirmation to stderr; other
commands' results go to stdout. `UNIAC_PROGRESS=1` enables progress on stderr;
`0` disables it. It does not affect stdout.

`plan --json` emits `{resource, digest, deployable}`, where `deployable` is
the generated service description. Its `env` and `start_command` fields are
included regardless of `--full`; that flag adds them to the text preview only.

`deploy` and `status` emit one final text report and have no JSON output mode.
For these commands, help and argument-parsing errors leave stdout empty.
Message wording and text layout are not a stable parsing interface.

Whole-project `status` reports volumes and their attachment state, including
retained unattached volumes; single-service `status` does not. Whole-project
`status` can omit service details or volumes when additional reads fail,
while still exiting 0.

Reported service state contains no image reference or digest. Allocated
public addresses appear in deployment and status output when the CLI can
read the service's state. [Platform behavior](platform.md) explains what
that state establishes.

## Exit codes

The following codes apply to `deploy` and `status`:

| Exit | Code | Current meaning |
|---|---|---|
| 0 | — | The command succeeded. |
| 2 | `usage` | Invalid invocation; no deployment attempted. |
| 3 | `auth` | No locally usable credential, or `status` has no project name. |
| 4 | `not_linked` | Binding/platform conflict, or deployment's project picker found no projects. |
| 5 | `manifest` | Manifest or deployment-shape error. |
| 6 | `build` | Docker, image-pull, or build failure. |
| 7 | `push` | Image upload failed. |
| 8 | `deploy_failed` | Deployment task failure, observation deadline expiry, or a refused platform read. |
| 9 | `unreachable` | The platform could not be reached. |
| 10 | `pending` | Reserved for unfinished work; currently not emitted. |
| 70 | `internal` | Unclassified error, including unattended project selection failures. |

Exit 1 is unassigned for these two commands. A rejected token can produce
7, 8, or 70 according to the operation. `retryable`, when reported,
indicates whether the same operation may succeed without changes.

For other commands, exit 1 indicates command failure and exit 2 indicates
an invalid invocation.
